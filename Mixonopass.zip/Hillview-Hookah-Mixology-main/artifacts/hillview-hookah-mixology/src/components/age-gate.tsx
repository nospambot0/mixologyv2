import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Flame, ShieldAlert } from 'lucide-react';

/**
 * Minimum age to enter the site. Change this one number if your local
 * legal smoking age is different.
 */
export const MIN_AGE = 18;

const VERIFIED_KEY = 'hillview-age-verified-at';
const DENIED_KEY = 'hillview-age-denied-at';
const VERIFIED_TTL_MS = 30 * 24 * 60 * 60 * 1000; // remember "yes" for 30 days
const DENIED_TTL_MS = 24 * 60 * 60 * 1000; // remember "no" for 24 hours

type Status = 'pending' | 'verified' | 'denied';

function isFresh(key: string, ttl: number): boolean {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return false;
    const at = Number(raw);
    if (!Number.isFinite(at)) return false;
    const age = Date.now() - at;
    if (age < 0 || age > ttl) {
      localStorage.removeItem(key);
      return false;
    }
    return true;
  } catch {
    return false;
  }
}

function remember(key: string) {
  try {
    localStorage.setItem(key, String(Date.now()));
  } catch {
    // Storage blocked (e.g. private mode): the gate still works for this visit.
  }
}

function readStatus(): Status {
  // A recent "under 18" answer wins, so refreshing the page does not bypass it.
  if (isFresh(DENIED_KEY, DENIED_TTL_MS)) return 'denied';
  if (isFresh(VERIFIED_KEY, VERIFIED_TTL_MS)) return 'verified';
  return 'pending';
}

export function AgeGate({ children }: { children: ReactNode }) {
  const [status, setStatus] = useState<Status>(readStatus);
  const confirmRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (status === 'pending') confirmRef.current?.focus();
  }, [status]);

  // The app is not rendered at all until the visitor confirms their age.
  if (status === 'verified') return <>{children}</>;

  const confirm = () => {
    remember(VERIFIED_KEY);
    setStatus('verified');
  };

  const deny = () => {
    remember(DENIED_KEY);
    setStatus('denied');
  };

  return (
    <div
      className="hv-app hv-noise relative flex min-h-dvh items-center justify-center overflow-hidden bg-primary px-5 py-10 text-primary-foreground"
      role="dialog"
      aria-modal="true"
      aria-labelledby="age-gate-title"
      aria-describedby="age-gate-description"
      data-testid="age-gate"
    >
      <div className="pointer-events-none absolute -right-24 -top-24 h-80 w-80 rounded-full border border-secondary/20 bg-secondary/10 blur-sm" />
      <div className="pointer-events-none absolute -bottom-32 -left-16 h-80 w-80 rounded-full bg-accent/10 blur-3xl" />

      <section className="hv-page-in relative w-full max-w-md text-center">
        <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-secondary text-secondary-foreground shadow-lg shadow-secondary/20">
          {status === 'denied' ? <ShieldAlert size={26} strokeWidth={1.8} /> : <Flame size={26} strokeWidth={1.8} />}
        </span>

        <p className="hv-mono mt-6 text-[10px] text-primary-foreground/60">HILLVIEW HOOKAH MIXOLOGY</p>

        {status === 'denied' ? (
          <>
            <h1 id="age-gate-title" className="hv-display mt-4 text-4xl leading-tight">
              Sorry, this site is for adults only.
            </h1>
            <p id="age-gate-description" className="mx-auto mt-5 max-w-sm text-sm leading-6 text-primary-foreground/70">
              You must be {MIN_AGE} or older to view Hillview Hookah Mixology. Please come back when you are of legal age.
            </p>
          </>
        ) : (
          <>
            <h1 id="age-gate-title" className="hv-display mt-4 text-4xl leading-tight">
              Are you {MIN_AGE} or older?
            </h1>
            <p id="age-gate-description" className="mx-auto mt-5 max-w-sm text-sm leading-6 text-primary-foreground/70">
              This site is about tobacco products and is only for adults. Please confirm your age to continue.
            </p>

            <div className="mt-9 flex flex-col gap-3">
              <button
                ref={confirmRef}
                type="button"
                className="hv-press flex min-h-14 items-center justify-center rounded-2xl bg-secondary px-6 font-bold text-secondary-foreground shadow-lg shadow-secondary/20"
                onClick={confirm}
                data-testid="button-age-confirm"
              >
                YES, I AM {MIN_AGE} OR OLDER
              </button>
              <button
                type="button"
                className="hv-press flex min-h-14 items-center justify-center rounded-2xl border border-primary-foreground/20 px-6 text-sm font-semibold text-primary-foreground hover:bg-primary-foreground/10"
                onClick={deny}
                data-testid="button-age-deny"
              >
                NO, I AM UNDER {MIN_AGE}
              </button>
            </div>
          </>
        )}

        <p className="mt-10 text-[11px] leading-5 text-primary-foreground/45">
          Tobacco is harmful to your health. Please enjoy responsibly.
        </p>
      </section>
    </div>
  );
}
