# Vercel deployment

This repository is configured to deploy from the repository root as a pnpm
workspace. The Vercel project should use the default root directory (`.`).

No environment variables, database or serverless functions are required.

The `/manage` screen is open (no password). It edits the flavour and premix
catalog in the visitor's own browser (`localStorage`), so changes are not
shared with other devices.

## Build settings

`vercel.json` already supplies:

- Install command: `pnpm install --frozen-lockfile`
- Build command: `pnpm --filter @workspace/hillview-hookah-mixology run build`
- Output directory: `artifacts/hillview-hookah-mixology/dist/public`

All routes fall back to the Vite SPA entry point.
